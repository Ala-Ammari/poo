#ifndef VALEUR_H_
#define VALEUR_H_

enum Valeur
{
	SEPT,
	HUIT,
	NEUF,
	DIX,
	VALET,
	DAME,
	ROI,
	AS
};


#endif