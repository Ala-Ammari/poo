#ifndef COULEUR_H_
#define COULEUR_H_

enum Couleur
{
	COEUR,
	CARREAU,
	PIQUE,
	TREFLE
};


#endif